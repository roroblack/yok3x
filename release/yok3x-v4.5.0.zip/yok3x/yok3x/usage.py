"""사용량 원장(usage.jsonl) + 요금 가드 + 사용량 코치.

- 모든 백엔드 호출 결과를 .yok3x/usage.jsonl에 1행 1이벤트로 기록한다(파일 기반 로그).
- guard: '진짜 한도'(limits.py의 서버 보고 실측)를 최우선으로 보고, 실측이 없으면
  자체 일일 예산(원장)으로 폴백해 soft_ratio 경고 / hard_ratio 루프 자동 정지.
- coach: 세 도구의 5시간/7일 사용률을 비교해 '어느 작업을 · 왜 · 언제' 코칭한다.

'한도는 무조건 지켜야 한다': 실측 probe가 있으면 그 값이 가드의 기준이다.
"""
from __future__ import annotations

import json
import math
import shutil
import time
import urllib.request
from dataclasses import dataclass, field
from datetime import datetime, timedelta
from pathlib import Path
from typing import Any

from . import limits
from .backends import BackendResult
from .config import Config

BACKEND_KEYS = ("claude", "codex", "gemini")


def record(cfg: Config, worker: str, task_kind: str, res: BackendResult) -> None:
    cfg.ensure_dirs()
    row = {
        "ts": time.time(),
        "date": datetime.now().strftime("%Y-%m-%d"),
        "worker": worker,
        "task_kind": task_kind,
        "backend": res.backend,
        "ok": res.ok,
        "cost_usd": res.cost_usd,
        "input_tokens": res.input_tokens,
        "output_tokens": res.output_tokens,
        "total_tokens": res.total_tokens,
        "duration_ms": res.duration_ms,
    }
    with cfg.paths.usage_file.open("a", encoding="utf-8") as f:
        f.write(json.dumps(row, ensure_ascii=False) + "\n")


# today_totals 캐시: (파일 mtime, size, 날짜) 가 같으면 재파싱 생략.
# GUI 폴링(7초)·가드 점검이 원장 전체를 반복 파싱하지 않게 하는 성능 캐시다.
# 데이터를 지어내지 않는다 — 원장이 바뀌면(mtime/size 변화) 즉시 재계산된다.
_TOTALS_CACHE: dict[str, tuple] = {}


def today_totals(cfg: Config) -> dict[str, dict[str, float]]:
    """백엔드별 오늘 누적 {usd, tokens, calls}. mock은 워커명으로 원 백엔드에 귀속."""
    totals = {k: {"usd": 0.0, "tokens": 0, "calls": 0} for k in BACKEND_KEYS}
    f = cfg.paths.usage_file
    if not f.exists():
        return totals
    today = datetime.now().strftime("%Y-%m-%d")
    try:
        st = f.stat()
        key = str(f)
        cached = _TOTALS_CACHE.get(key)
        if cached and cached[0] == (st.st_mtime_ns, st.st_size, today):
            return {k: dict(v) for k, v in cached[1].items()}
    except OSError:
        st = None
    for line in f.read_text(encoding="utf-8").splitlines():
        try:
            row = json.loads(line)
        except json.JSONDecodeError:
            continue
        if row.get("date") != today:
            continue
        b = row.get("backend", "")
        if b == "mock":
            # mock 호출은 워커명으로 원 백엔드에 귀속. 유추 불가면 집계 제외(오귀속 방지)
            b = _worker_backend_name(cfg, row.get("worker", "")) or ""
        if b not in totals:
            continue
        totals[b]["usd"] += float(row.get("cost_usd", 0) or 0)
        totals[b]["tokens"] += int(row.get("total_tokens", 0) or 0)
        totals[b]["calls"] += 1
    if st is not None:
        _TOTALS_CACHE[str(f)] = ((st.st_mtime_ns, st.st_size, today),
                                 {k: dict(v) for k, v in totals.items()})
    return totals


def _worker_backend_name(cfg: Config, worker: str) -> str | None:
    """워커 → 실제 백엔드명. 확정 못 하면 None (지어내지 않는다)."""
    w = cfg.yok3x.get("workers", {}).get(worker)
    if not w:
        return None
    name = w.get("backend", "")
    # mock(드라이런)으로 스위치된 경우 워커 이름 접두사로 원 백엔드 유추
    if name == "mock":
        for k in BACKEND_KEYS:
            if worker.startswith(k):
                return k
        return None  # 유추 불가 — 폴백으로 지어내지 않음(호출부가 보수적으로 처리)
    return name if name in BACKEND_KEYS else None


# ---------------------------------------------------------------- guard

@dataclass
class GuardVerdict:
    backend: str
    ratio: float          # 가장 높은 사용률(0~). 한도는 '가장 빡빡한 창' 기준
    metric: str           # 그 사용률의 기준 지표
    level: str            # ok | warn | stop
    detail: str
    source: str = "ledger"                    # codex_sessions | claude_transcripts | command | ledger
    real: bool = False                        # 서버 보고 실측이면 True
    reading: limits.LimitReading | None = None  # 실측 원본(coach/mat용)


def _level(g: dict, ratio: float) -> str:
    if not g.get("enabled", True):
        return "ok"
    if ratio >= g.get("hard_ratio", 1.0):
        return "stop"
    if ratio >= g.get("soft_ratio", 0.8):
        return "warn"
    return "ok"


# ---------------------------------------------------------------- 하루 페이싱(주간쿼터 대비)

_SEVERITY = {"ok": 0, "warn": 1, "stop": 2}


def _pace_cfg(cfg: Config, backend: str) -> dict:
    """전역 daily_pace + 백엔드별 override 병합 + 값 검증/클램프(파일에서 온 잘못된 값 방어)."""
    dp = dict((cfg.yok3x.get("guard") or {}).get("daily_pace") or {})
    bo = (dp.get("backends") or {}).get(backend)
    if isinstance(bo, dict):
        dp.update(bo)
    try:
        pct = float(dp.get("pct_of_weekly", 0.14))
    except (TypeError, ValueError):
        pct = 0.14
    dp["pct_of_weekly"] = min(1.0, max(0.01, pct)) if math.isfinite(pct) else 0.14
    try:
        sf = float(dp.get("soft_frac", 0.8))
    except (TypeError, ValueError):
        sf = 0.8
    dp["soft_frac"] = min(0.99, max(0.0, sf)) if math.isfinite(sf) else 0.8
    if dp.get("mode") not in ("warn", "pause"):
        dp["mode"] = "warn"
    # 하루 상한 산정 전략: fixed(고정 pct_of_weekly) | catch_up(기준선 따라잡기, 초과 시 즉시 조임·안 쓰면 회복)
    # | spread(남은 예산을 남은 일수로 균등 분배 — 초과분도 고르게 펴서 상한이 덜 급격히 떨어짐).
    if dp.get("strategy") not in ("fixed", "catch_up", "spread"):
        dp["strategy"] = "fixed"
    try:                                          # catch_up 안전 캡 배수(하루 상한 ≤ max_cap_mult×q)
        mm = float(dp.get("max_cap_mult", 2.0))
    except (TypeError, ValueError):
        mm = 2.0
    dp["max_cap_mult"] = min(7.0, max(1.0, mm)) if math.isfinite(mm) else 2.0
    return dp


def _weekly_pct(reading: "limits.LimitReading | None") -> float | None:
    """실측 reading의 주간(7d) '집계' 창 used_percent. 정확히 '7d' 우선, 없으면 7d 접두 최대."""
    wins = getattr(reading, "windows", None) or []
    exact = [float(w.used_percent) for w in wins if str(w.name) == "7d"]
    if exact:
        return exact[0]
    pref = [float(w.used_percent) for w in wins if str(w.name).startswith("7d")]
    return max(pref) if pref else None


def _pacing_day_start(reset_at: float | None, now: float | None = None) -> float:
    """'페이싱 하루'의 시작 시각. 하루 경계는 **자정이 아니라 실제 리셋 시각에 정렬**한다(주간 창이
    예: 오후 6시에 리셋되면 하루도 오후 6시~오후 6시). reset_at에서 86400초씩 뒤로 물러난 경계 중
    now 직전(≤now)의 것. reset_at 없으면 달력 자정 폴백."""
    now = now if now is not None else time.time()
    if not reset_at or not math.isfinite(reset_at):
        return datetime.now().replace(hour=0, minute=0, second=0, microsecond=0).timestamp()
    days_ahead = math.ceil((reset_at - now) / 86400.0)
    return reset_at - days_ahead * 86400.0


def _pacing_day_key(reset_at: float | None, now: float | None = None) -> str:
    """리셋 정렬된 페이싱 하루 식별 키(레코드 일일 초기화용). 경계가 바뀌면 값이 바뀐다.
    **분 단위로 양자화**(//60): reset_at이 초 이하로 드리프트(예: ...400.41↔.50)해도 키가 안 튀게 —
    round()면 .5 경계에서 튀어 매 폴 '새 하루'로 오인 → start_pct 재캡처로 오늘 소비가 0으로 리셋되는
    버그(사용자 지적)가 났다. 리셋 시각은 분 정밀도면 충분하다."""
    if not reset_at or not math.isfinite(reset_at):
        return (datetime.fromtimestamp(now) if now else datetime.now()).strftime("%Y-%m-%d")
    return f"pd{int(_pacing_day_start(reset_at, now) // 60)}"


def today_used_pct(cfg: Config, backend: str, reset_at: float | None = None) -> float | None:
    """**오늘(리셋 정렬 하루 시작 이후) 실제 사용률**. 7d 롤링% 델타는 롤오프에 상쇄돼 오늘 사용을
    0으로 뭉갠다(사용자 지적). claude는 하루 시작 이후 실제 소비 토큰으로 정확히 계산한다(예: 6.4%).
    하루 경계는 자정이 아니라 **리셋 시각에 정렬**(reset_at 기준). 토큰 없음/타 백엔드/미보정은 None."""
    if backend != "claude":
        return None
    try:
        conf = (cfg.yok3x.get("limits") or {}).get("claude") or {}
        now = time.time()
        day_start = _pacing_day_start(reset_at, now)
        secs = max(0.0, now - day_start)
        tok = limits._rolling_claude_tokens(limits._claude_root(conf), now, secs)
        _, cap7 = limits._resolve_claude_caps(conf)
        if cap7 and cap7 > 0 and tok >= 0:
            return round(100.0 * tok / cap7, 1)
    except Exception:
        pass
    return None


def reading_since_reset_pct(reading: "limits.LimitReading | None") -> float | None:
    """실측 reading(oauth/statusline)의 7d used_percent — 페이싱 since-reset의 **가장 정확한 소스**.
    바 게이지(창 used_percent)와 동일 소스라 페이싱 밴드가 바 채움과 어긋나지 않는다(사용자 지적:
    바=OAuth·페이싱=트랜스크립트 불일치로 '상한까지 남은 부분' 밴드 소실). 실측 아니거나 7d 없으면 None."""
    if reading is None or not getattr(reading, "real", False):
        return None
    for w in (getattr(reading, "windows", None) or []):
        if getattr(w, "name", None) == "7d":
            try:
                return float(w.used_percent)
            except (TypeError, ValueError):
                return None
    return None


def _pace_inputs(cfg: Config, backend: str, reading: "limits.LimitReading | None",
                 reset_at: float | None) -> tuple[float | None, bool, float | None]:
    """페이싱 입력 (current, since_reset_known, today_used)을 소스 일관성 있게 고른다.
    - 실측 reading의 7d%가 있으면(OAuth/app-server) 그걸 current로 쓰되 **since_reset_known=False,
      today_used=None** — OAuth는 주간 %만 주고 일간 분해가 없어, 트랜스크립트 today_used(다른 소스)와
      빼면 상한이 요동친다(사용자 지적 버그: 오늘 쓸수록 상한↑). codex처럼 하루시작 스냅샷 모델로 가야
      상한이 하루 안 안정적이고 바 게이지와도 일치.
    - 없으면 트랜스크립트 since-reset(같은 소스 today_used와 짝) → since_reset_known=True, token today_used.
    - 그것도 없으면 롤링 %(since_reset_known=False)."""
    r7 = reading_since_reset_pct(reading)     # OAuth/statusline 주간%(정확한 총량, 정수)
    if r7 is not None:
        # OAuth엔 일간 분해가 없다. 순수 스냅샷(오늘=현재−하루시작값)은 프로세스 재기동·소스플립 때
        # start_pct가 현재값으로 재캡처돼 '오늘=0'으로 붕괴하고 상한(=하루시작값 기반)이 흔들렸다
        # (사용자 지적: 오늘 실제로 썼는데 0, 상한 11→10.3 실시간 하락). 해결: 트랜스크립트(과거 토큰이라
        # 재기동에 불변)의 오늘/이번주 비율로 OAuth 총량을 '오늘분'으로 환산 → since_reset_known=True 경로가
        # u0=현재−오늘(=오늘이전, 과거값이라 하루 안 고정)로 상한을 안정적으로 낸다. 스케일을 OAuth에
        # 맞추므로(BUG-33의 무보정 혼합과 달리) 요동 없음.
        tr_week = weekly_used_since_reset(cfg, backend, reset_at)
        tr_today = today_used_pct(cfg, backend, reset_at)
        if tr_week and tr_week > 0 and tr_today is not None:
            today_scaled = round(min(r7, tr_today * (r7 / tr_week)), 1)   # 오늘분(OAuth 스케일)
            return r7, True, today_scaled
        return r7, False, None                # 트랜스크립트 없으면 스냅샷 폴백
    sr = weekly_used_since_reset(cfg, backend, reset_at)
    if sr is not None:
        return sr, True, today_used_pct(cfg, backend, reset_at)
    return precise_weekly_pct(cfg, backend, reading), False, None


def weekly_used_since_reset(cfg: Config, backend: str, reset_at: float | None) -> float | None:
    """**이번 주(마지막 리셋 이후) 실제 사용률**. 7d 롤링%는 리셋 전 사용까지 포함해(예: 롤링 27%인데
    리셋 이후는 13.6%) 상한을 과다 차감한다(사용자 지적: 상한 0.9% 버그). claude는 마지막 리셋
    (reset_at − 7일) 이후 실제 토큰으로 이번 주 사용을 정확히 낸다. reset_at 없음/타 백엔드는 None."""
    if backend != "claude" or not reset_at or not math.isfinite(reset_at):
        return None
    try:
        conf = (cfg.yok3x.get("limits") or {}).get("claude") or {}
        now = time.time()
        last_reset = reset_at - 7 * 86400.0
        secs = max(0.0, now - last_reset)
        tok = limits._rolling_claude_tokens(limits._claude_root(conf), now, secs)
        _, cap7 = limits._resolve_claude_caps(conf)
        if cap7 and cap7 > 0 and tok >= 0:
            return round(100.0 * tok / cap7, 1)
    except Exception:
        pass
    return None


def precise_weekly_pct(cfg: Config, backend: str,
                       reading: "limits.LimitReading | None") -> float | None:
    """페이싱용 7d%. 소스 used_percent는 **정수로 양자화**돼(예: 17.28%가 17%로) 하루치가 1% 미만이면
    '오늘 사용량'이 0으로 뭉개지고 상한 누적도 부정확했다(사용자 지적 버그). claude는 토큰 기반으로
    **소수 정밀도**(17.28%)를 낼 수 있으니 그걸 쓴다. 단 cap 미보정 시 토큰이 캐시로 크게 부풀 수 있어
    (768% 전례), 정수 소스와 5%p 이내로 근접할 때만 정밀값을 신뢰한다. 그 외/타 백엔드는 소스 폴백."""
    base = _weekly_pct(reading)
    if base is None or backend != "claude":
        return base
    try:
        conf = (cfg.yok3x.get("limits") or {}).get("claude") or {}
        tok7 = limits.claude_rolling_tokens(conf, "7d")
        _, cap7 = limits._resolve_claude_caps(conf)
        if cap7 and cap7 > 0 and tok7 and tok7 > 0:
            precise = 100.0 * tok7 / cap7
            if abs(precise - base) <= 5.0:        # 보정된 상태(정수 소스에 근접) → 정밀값 채택
                return precise
    except Exception:
        pass
    return base


def _weekly_reset_at(reading: "limits.LimitReading | None") -> float | None:
    """정확히 '7d' 집계 창의 리셋 epoch(catch-up 페이싱의 남은 일수 계산용). 없으면 None."""
    for w in (getattr(reading, "windows", None) or []):
        if str(w.name) == "7d":
            ra = getattr(w, "resets_at", None)
            return float(ra) if ra else None
    return None


def effective_reset_at(cfg: Config, backend: str,
                       reading: "limits.LimitReading | None") -> float | None:
    """7d 리셋 epoch — reading에 있으면 그 값(+pace.json에 캐시), 없으면(oauth 실패→transcript 폴백)
    마지막 캐시값을 쓴다. reset_at이 플랩해도 since-reset 상한·하루 경계가 안정된다(사용자 지적:
    상한 0.7% 고착 = reset_at None → 롤링 폴백 + stale 키). 캐시가 과거면 주 단위로 전진(리셋 주기적)."""
    ra = _weekly_reset_at(reading)
    st = _load_pace(cfg)
    rec = st.get(backend) if isinstance(st.get(backend), dict) else {}
    if ra and math.isfinite(ra):
        if rec.get("reset_at_cache") != ra:
            rec["reset_at_cache"] = ra
            st[backend] = rec
            _save_pace(cfg, st)
        return ra
    cached = rec.get("reset_at_cache")
    if cached and math.isfinite(float(cached)):
        c, now = float(cached), time.time()
        while c < now:                            # 지난 값이면 주 단위 전진(리셋은 7일 주기)
            c += 7 * 86400.0
        return c
    return None


def _pace_file(cfg: Config) -> Path:
    return cfg.paths.yok3x_dir / "pace.json"


def _load_pace(cfg: Config) -> dict:
    p = _pace_file(cfg)
    try:
        if not p.exists():
            return {}
        d = json.loads(p.read_text(encoding="utf-8"))
        return d if isinstance(d, dict) else {}
    except (json.JSONDecodeError, OSError):
        # 손상 파일: 조용히 {}로 리셋하면 기준점이 사라져 cap 우회 가능 → 백업만 남기고 빈 상태.
        try:
            p.replace(p.with_suffix(".json.corrupt"))
        except OSError:
            pass
        return {}


def _save_pace(cfg: Config, state: dict) -> None:
    cfg.ensure_dirs()
    p = _pace_file(cfg)
    tmp = p.with_suffix(".json.tmp")
    tmp.write_text(json.dumps(state, ensure_ascii=False), encoding="utf-8")
    tmp.replace(p)   # 원자적 교체(같은 볼륨) — torn write로 인한 상태 유실 방지


def _catch_up_cap(q: float, u0: float, reset_at: float | None, max_mult: float,
                  now: float | None = None) -> float:
    """catch-up 하루 상한(codex 설계). 균등 허용선(경과일×q)에서 오늘 첫 실측(u0)을 빼 '몰아쓸 수
    있는 여유'를 준다. 안전 캡 max_mult×q로 마지막 날 폭발 방지. reset_at 없으면 고정 q로 폴백.
        D = clamp(1,7, ceil(남은초/86400)) · k = 8-D(오늘 포함 경과일) · cap = min(max_mult·q, max(0, min(100,k·q)-u0))
    """
    if not reset_at or not math.isfinite(reset_at):
        return q                                 # 리셋 정보 없으면 고정(안전 폴백)
    now = now if now is not None else time.time()
    remaining = reset_at - now
    if not math.isfinite(remaining):
        return q
    D = max(1, min(7, math.ceil(remaining / 86400.0)))
    k = 8 - D                                     # 창의 몇째 날(오늘 포함, 1~7)
    raw = max(0.0, min(100.0, k * q) - max(0.0, u0))
    return min(max_mult * q, raw)


def _spread_cap(q: float, u0: float, reset_at: float | None, max_mult: float,
                now: float | None = None) -> float:
    """spread 전략: 남은 예산(100−u0)을 남은 일수로 **균등 분배**. 초과했을 때 상한을 즉시 확
    낮추는 catch_up과 달리 초과분도 남은 날에 고르게 편다(하루 상한이 덜 급격히 떨어짐).
    안전 캡 max_mult×q 유지. 리셋 정보 없으면 고정 q 폴백."""
    if not reset_at or not math.isfinite(reset_at):
        return q
    now = now if now is not None else time.time()
    remaining = reset_at - now
    if not math.isfinite(remaining):
        return q
    D = max(1, min(7, math.ceil(remaining / 86400.0)))
    raw = max(0.0, 100.0 - max(0.0, u0)) / D
    return min(max_mult * q, raw)


def _daily_cap(strategy: str, q: float, u0: float, reset_at: float | None,
               max_mult: float, now: float | None = None) -> float:
    """전략별 하루 상한. fixed=고정 q · catch_up=기준선 따라잡기(즉시 조임) · spread=균등 분배."""
    if strategy == "catch_up":
        return _catch_up_cap(q, u0, reset_at, max_mult, now)
    if strategy == "spread":
        return _spread_cap(q, u0, reset_at, max_mult, now)
    return q                                       # fixed


def daily_pace_status(cfg: Config, backend: str, current_pct: float | None,
                      today: str | None = None, reset_at: float | None = None,
                      today_used: float | None = None,
                      since_reset_known: bool = True) -> dict | None:
    """하루 페이싱 상태. current_pct=현재 7d used_percent(실측). enabled off / 7d 없으면 None.
    today_used(있으면): 오늘 실제 사용률을 직접 지정(자정 이후 실제 토큰 — 7d% 델타 롤오프 뭉갬 대체).
    오늘소비 = today_used가 있으면 그 값, 없으면 '첫 관측 이후 7d%의 양의 증분 누적'. pause 모드는 cap 도달 시
    blocked를 저장해 값이 낮아져도 자동 재개하지 않고 승인/자정까지 정지 유지.
    reset_at(7d 창 리셋 epoch)이 있고 strategy=catch_up이면 남은 일수로 유동 상한을 낸다.
    since_reset_known: current_pct가 '이번 주(리셋 이후) 실측'이면 True(claude — 토큰 기반). codex처럼
      토큰이 없어 current_pct가 **7d 롤링 %**이면 False. False면 오늘 사용·상한 앵커를 '하루 시작 시점
      스냅샷(start_pct)' 기준으로 낸다: 주간 첫날은 리셋서 0%였으니 start_pct=0 → 현재 롤링%가 곧 오늘 사용,
      상한은 기준(q)을 온전히(사용자 지적: 리셋 직후 5% 썼으면 오늘 5/상한 14). 이후 날은 하루 시작 롤링%가
      기준선. 안 그러면 상한이 롤링 % 따라 계속 줄어든다(codex '상한만 줄고 사용량만 늘고')."""
    dp = _pace_cfg(cfg, backend)
    if not dp.get("enabled") or current_pct is None:
        return None
    try:
        current = float(current_pct)
    except (TypeError, ValueError):
        return None
    if not math.isfinite(current):
        return None
    today = today or datetime.now().strftime("%Y-%m-%d")
    q = dp["pct_of_weekly"] * 100.0               # 기본 하루치(균등 14%p)
    mode = dp["mode"]
    # 창 세대 마커: resets_at이 바뀌면(새 주간 창) 롤오프가 아니라 진짜 리셋 → 당일 기준 재초기화.
    # **분 단위 양자화**(//60): reset_at 초 이하 드리프트(.5 경계)에 round()가 튀어 매 폴 spurious 리셋 →
    # start_pct 재캡처로 오늘 소비 0 리셋되던 버그 방지(사용자 지적). 진짜 주간 리셋은 분 단위로 충분히 구분.
    win_gen = int(float(reset_at) // 60) if (reset_at and math.isfinite(reset_at)) else None
    st = _load_pace(cfg)
    rec = st.get(backend) if isinstance(st.get(backend), dict) else {}
    changed = False
    win_changed = rec.get("win") != win_gen
    day_changed = rec.get("date") != today
    # 이번 페이싱 하루가 '주간 창 첫날'인가 = 하루 시작이 마지막 리셋과 같은가. codex(토큰없음)의 오늘/앵커
    # 추정에 쓴다: 첫날은 하루 시작=리셋이라 '오늘 이전 사용'이 0이고 현재 롤링%가 곧 이번주=오늘 사용.
    _now = time.time()
    _last_reset = (reset_at - 7 * 86400.0) if (reset_at and math.isfinite(reset_at)) else None
    is_day1 = (_last_reset is not None
               and abs(_pacing_day_start(reset_at, _now) - _last_reset) < 1.0)
    # 새 날(리셋정렬 경계) 또는 새 창(주간 리셋)이면 하루 기준 초기화. base='오늘 이전 이번주 사용'(상한 앵커
    # u0 겸 오늘 사용의 기준선). claude는 since-reset 실측(current). codex는 토큰이 없어 롤링%≈since-reset로
    # 추정하되, 첫날이면 리셋서 0%였으니 base=0(현재 롤링%가 곧 오늘 사용). cap_today는 여기서 한 번 고정.
    _tu0 = float(today_used) if today_used is not None else 0.0
    if day_changed or win_changed:
        # 하루 시작 기준선(base) = '오늘 이전 이번주 사용'. claude(토큰)는 since-reset에서 오늘분을 빼(오늘
        # 쓸수록 상한이 깎이지 않게), codex(토큰없음)는 첫날 0·이후 하루시작 스냅샷.
        base = max(0.0, current - _tu0) if since_reset_known else (0.0 if is_day1 else current)
        cap_today = _daily_cap(dp["strategy"], q, base, reset_at, dp["max_cap_mult"])
        rec = {"date": today, "win": win_gen, "start_pct": base, "last_pct": current,
               "used_today": max(0.0, current - base), "blocked": False,
               "cap_today": cap_today, "strat": dp["strategy"]}
        changed = True
    elif rec.get("strat") != dp["strategy"]:
        # 하루 중 전략을 바꾸면 즉시 반영한다(당일 재초기화 없이). u0는 하루 시작 기준선(start_pct)을 써
        # 사용량 누적을 보존한다 — current로 재계산하면 몰아쓴 뒤 상한이 준다.
        base = float(rec.get("start_pct", current))
        u0_strat = current if since_reset_known else base
        rec["cap_today"] = _daily_cap(dp["strategy"], q, u0_strat, reset_at, dp["max_cap_mult"])
        rec["strat"] = dp["strategy"]
        changed = True
    else:
        if since_reset_known:                    # claude: 표시는 today_used(토큰)로 덮이나 폴백 누적 유지
            last = float(rec.get("last_pct", current))
            if current - last > 0:
                rec["used_today"] = float(rec.get("used_today", 0.0)) + (current - last)
                changed = True
        else:                                    # codex: 오늘 = 하루시작 스냅샷(start_pct) 대비 현재 롤링%
            nu = max(0.0, current - float(rec.get("start_pct", current)))   # 롤오프 하락도 자기보정
            if nu != float(rec.get("used_today", 0.0)):
                rec["used_today"] = nu
                changed = True
        if rec.get("last_pct") != current:
            rec["last_pct"] = current
            changed = True
    # 하루 상한. claude(토큰): '오늘 이전 이번주 사용'(current−today_used)으로 **매 폴 재계산**한다 —
    # 이 값은 과거 데이터라 하루 안에서 안정적이고, 오늘 쓸수록 상한이 깎이던 문제(사용자 지적)가 사라진다.
    # codex(토큰없음)·reset 정보 없음: 하루 시작에 고정한 cap_today(스냅샷 기준, 없으면 고정 q 폴백).
    if since_reset_known and reset_at and math.isfinite(reset_at):
        _u0 = max(0.0, current - _tu0)
        cap = _daily_cap(dp["strategy"], q, _u0, reset_at, dp["max_cap_mult"])
    else:
        cap = float(rec.get("cap_today", q))
        _u0 = float(rec.get("start_pct", current))
    # 엄격 균등선(catch_up) 기준 '오늘 더 써도 되는 양'을 전략과 무관하게 함께 계산해 오버레이에 노출.
    # 메인 줄엔 지속가능률(전략 상한, 하루 고정)을 안정적으로 보이고, 쓴 만큼 줄어드는 이 값은
    # 오버레이에만 — 사용자 설계("줄어드는 건 오버레이에만"). reset 정보 없으면 상한과 동일.
    even_cap = (round(_catch_up_cap(q, _u0, reset_at, dp["max_cap_mult"]), 1)
                if (reset_at and math.isfinite(reset_at)) else round(cap, 1))
    soft = cap * dp["soft_frac"]
    # 오늘 사용: today_used(자정 이후 실제 토큰)가 있으면 그걸 쓴다 — 7d% 델타는 롤오프로 오늘을
    # 0으로 뭉개므로(사용자 지적). 없으면 기존 델타 누적 폴백.
    used = float(today_used) if today_used is not None else float(rec.get("used_today", 0.0))
    if mode == "pause" and used >= cap and not rec.get("blocked"):
        rec["blocked"] = True                    # sticky: 그날은 정지 유지
        changed = True
    blocked = bool(rec.get("blocked"))
    if changed:
        st[backend] = rec
        _save_pace(cfg, st)
    ovr = (cfg.yok3x.get("guard") or {}).get("daily_pace_override") or {}
    approved = ovr.get(backend) == today
    if approved:                                 # 승인된 날: 페이싱 판정 전체 우회(soft 포함)
        level = "ok"
    elif mode == "pause" and blocked:
        level = "stop"
    elif used >= cap:
        level = "stop" if mode == "pause" else "warn"
    elif used >= soft:
        level = "warn"
    else:
        level = "ok"
    # 이후 지속가능 일일률: **일간 사용량을 초과했을 때만**(used>=cap) 의미가 있다(사용자). 오늘 상한
    # 안에서 쓰고 있으면(under) 남은 분은 다음날로 이월되므로(catch_up이 내일 상한을 올림) 나눗셈을
    # 보이지 않는다. 초과 시엔 '리셋까지 남은 예산(100-현재)을 남은 일수로 나눠 하루 몇 %씩'을 안내.
    forward_daily = None
    if reset_at and math.isfinite(reset_at) and used >= cap:
        remaining_days = max(1, min(7, math.ceil((reset_at - time.time()) / 86400.0)))
        forward_daily = round(max(0.0, 100.0 - current) / remaining_days, 1)
    return {"used": used, "cap": cap, "soft": soft, "blocked": blocked,
            "current": current, "level": level, "mode": mode, "approved": approved,
            # 균등 기준선(고정 q)도 함께 노출 — 유동 상한이 원래 하루치 대비 얼마인지 보이게.
            "base_cap": q, "strategy": dp["strategy"],
            # even_cap: 엄격 균등선(catch_up) 기준 '오늘 여유' — 오버레이 전용(쓴 만큼 줄어드는 값).
            "even_cap": even_cap,
            "forward_daily": forward_daily}


def pace_block_active(cfg: Config, backend: str, today: str | None = None) -> bool:
    """저장된 sticky pause 정지가 오늘 유효한가(probe 실패 중에도 정지 유지). 승인/자정 전까지 True."""
    dp = _pace_cfg(cfg, backend)
    if not dp.get("enabled") or dp.get("mode") != "pause":
        return False
    today = today or datetime.now().strftime("%Y-%m-%d")
    rec = _load_pace(cfg).get(backend)
    if not isinstance(rec, dict) or rec.get("date") != today or not rec.get("blocked"):
        return False
    ovr = (cfg.yok3x.get("guard") or {}).get("daily_pace_override") or {}
    return ovr.get(backend) != today


def pace_approve(cfg: Config, backend: str, today: str | None = None) -> None:
    """하루 페이싱 정지를 '오늘 하루' 해제(승인 재개). override가 그날의 판정을 우선한다."""
    today = today or datetime.now().strftime("%Y-%m-%d")
    cfg.yok3x.setdefault("guard", {}).setdefault("daily_pace_override", {})[backend] = today


def check_backend(cfg: Config, backend: str) -> GuardVerdict:
    """한도 판정. 실측 probe가 있으면 그것이 기준, 없으면 원장(일일 예산) 폴백."""
    g = cfg.yok3x["guard"]

    # 1) 진짜 한도 우선 — limits.py 의 서버 보고 실측/롤링 추정
    if g.get("use_real_limits", True):
        reading = limits.probe(cfg, backend)
        if reading.ok and reading.windows:
            ratio = reading.ratio()
            w = reading.worst()
            metric = f"{w.name}·{reading.source}" if w else reading.source
            level = _level(g, ratio)
            tag = "" if reading.real else " (추정)"
            # 미보정 추정(real=False)이 비현실적으로 높으면(>300%) 신뢰 불가 → 정지 대신 경고.
            # (트랜스크립트 롤링은 캐시read 포함해 과대. 실측 실패 시 false-stop 방지 — calibrate 권장)
            if not reading.real and level == "stop" and ratio > 3.0:
                level = "warn"
                tag += " ⚠미보정(정지 유보; `yok3x calibrate` 권장)"
            # 하루 페이싱 — 실측(real) 7d에만 적용(미보정 추정으로 오정지 방지). 절대 한도에 '덧붙는' 층.
            if reading.real:
                _ra = effective_reset_at(cfg, backend, reading)
                _cur, _known, _tu = _pace_inputs(cfg, backend, reading, _ra)
                pace = daily_pace_status(cfg, backend, _cur,
                                         today=_pacing_day_key(_ra), reset_at=_ra,
                                         today_used=_tu, since_reset_known=_known)
                if pace and pace["level"] != "ok":
                    tag += (f" · 하루페이싱 {pace['used']:.0f}/{pace['cap']:.0f}%p"
                            + ("(승인 필요)" if pace["level"] == "stop" else ""))   # 동일 severity라도 표시
                    if _SEVERITY[pace["level"]] > _SEVERITY[level]:
                        level = pace["level"]
                        metric = "daily_pace"
                        if pace["cap"]:
                            ratio = min(pace["used"] / pace["cap"], 9.99)   # UI 오해 방지: pace 비율로
            return GuardVerdict(backend, ratio, metric, level,
                                reading.detail + tag, source=reading.source,
                                real=reading.real, reading=reading)
        # 실측 probe가 설정됐으나 실패 → 정책에 따라
        if reading.source not in ("ledger", "disabled", "none") and reading.error:
            policy = g.get("on_probe_failure", "ledger")
            if policy == "block" and g.get("enabled", True):
                return GuardVerdict(backend, 1.0, "probe_fail", "stop",
                                    f"실측 probe 실패 → 차단(fail-closed): {reading.error}",
                                    source=reading.source, real=False, reading=reading)
            # policy == "ledger"(기본) 또는 "allow" → 아래 원장 폴백으로

    # 2) 원장 폴백 — 단, 하루 페이싱 sticky 정지가 걸려 있으면 측정 실패 중에도 정지 유지(승인/자정 전까지).
    if g.get("enabled", True) and pace_block_active(cfg, backend):
        return GuardVerdict(backend, 1.0, "daily_pace", "stop",
                            "하루 페이싱 정지 유지(측정 실패 중) — `yok3x pace approve`로 오늘 재개",
                            source="ledger")
    return _check_backend_ledger(cfg, backend)


def _check_backend_ledger(cfg: Config, backend: str) -> GuardVerdict:
    g = cfg.yok3x["guard"]
    budgets = cfg.yok3x["budgets"].get(backend, {})
    totals = today_totals(cfg).get(backend, {"usd": 0, "tokens": 0, "calls": 0})
    ratios: list[tuple[float, str, str]] = []
    if budgets.get("daily_usd"):
        r = totals["usd"] / budgets["daily_usd"]
        ratios.append((r, "daily_usd", f"${totals['usd']:.2f}/${budgets['daily_usd']:.2f}"))
    if budgets.get("daily_tokens"):
        r = totals["tokens"] / budgets["daily_tokens"]
        ratios.append((r, "daily_tokens", f"{totals['tokens']:,}/{budgets['daily_tokens']:,} tok"))
    if budgets.get("daily_calls"):
        r = totals["calls"] / budgets["daily_calls"]
        ratios.append((r, "daily_calls", f"{totals['calls']}/{budgets['daily_calls']} calls"))
    if not ratios:
        return GuardVerdict(backend, 0.0, "-", "ok", "예산 미설정", source="ledger")
    ratio, metric, detail = max(ratios, key=lambda x: x[0])
    level = _level(g, ratio)
    if not g.get("enabled", True):
        detail += " (guard off)"
    return GuardVerdict(backend, ratio, metric, level, detail, source="ledger")


def guard_allows(cfg: Config, worker: str) -> tuple[bool, GuardVerdict]:
    """루프가 이 워커를 지금 호출해도 되는가. stop이면 False → 루프 자동 정지.

    [의도된 폴백] 백엔드를 확정 못 하는 워커는 'claude' 예산으로 보수 점검한다 —
    아무 예산도 점검하지 않는 것(가드 우회)보다 안전한 쪽을 택한 것.
    (reports/*-fallback-hardcoding-audit-* 레지스트리 등재 항목)
    """
    b = _worker_backend_name(cfg, worker) or "claude"
    v = check_backend(cfg, b)
    return v.level != "stop", v


def backend_available(cfg: Config, backend: str) -> bool:
    """S2 라우팅 필터: 이 backend를 지금 쓸 수 있는가 = CLI 설치 + 한도 여유(stop 아님).

    설치 안 됐거나 한도가 꽉 찼으면 False → resolve_model이 다음 순위로 폴백한다.
    판정 자체가 실패하면(예외) 보수적으로 True(라우팅을 막지 않음)."""
    spec = (cfg.backends or {}).get(backend) or {}
    cmd = spec.get("command") or []
    btype = spec.get("type", "cli")
    if btype == "cli":
        if not cmd or shutil.which(str(cmd[0])) is None:
            return False        # CLI 미설치
    try:
        return check_backend(cfg, backend).level != "stop"   # 한도 여유
    except Exception:
        return True


def failover_backend(cfg: Config, worker: str, exclude: str, switches_used: int) -> str | None:
    """P2 백엔드 폴오버 + P3 오프라인 폴백. exclude(한도초과/불가) 대신 쓸 backend를 고른다.

    P2(클라우드↔클라우드): `failover_enabled` on일 때, 설치+여유(backend_available)한 '다른 클라우드'
    중 사용률(ratio) 최소를 고른다. 오프라인 backend는 여기서 제외(마지막 수단이라).
    P3(클라우드→로컬): 클라우드 대안이 없고 `offline_enabled`면, 로컬 서버가 실제로 떠 있을 때만
    `offline_backend`(local)로 강등해 무중단. 반환 None: 역할 제외·런당 상한 초과·대안 없음.
    """
    d = (cfg.yok3x.get("guard") or {}).get("degrade") or {}
    if worker in (d.get("roles_no_failover") or []):
        return None
    if switches_used >= int(d.get("max_failovers_per_run", 3)):
        return None
    offline_b = d.get("offline_backend", "local")
    # P2: 클라우드 간 폴오버(오프라인 backend는 후보에서 뺀다)
    best, best_ratio = None, None
    if d.get("failover_enabled"):
        for b in (cfg.backends or {}):
            if b in (exclude, "mock", offline_b) or not backend_available(cfg, b):
                continue
            try:
                r = check_backend(cfg, b).ratio
            except Exception:
                r = 0.0
            if best_ratio is None or r < best_ratio:
                best, best_ratio = b, r
    if best is not None:
        return best
    # P3: 클라우드 대안 없음 → 로컬로 강등(설정 on + 로컬 서버 도달 가능할 때만)
    if d.get("offline_enabled", True) and offline_b and offline_b != exclude:
        if offline_reachable(cfg, offline_b):
            return offline_b
    return None


def offline_reachable(cfg: Config, backend: str = "local") -> bool:
    """로컬 OpenAI 호환 서버가 지금 응답하는지 짧게 확인(GET /models). 죽은 엔드포인트로
    강등하지 않기 위함. 실패/타임아웃이면 False."""
    spec = (cfg.backends or {}).get(backend) or {}
    base = str(spec.get("base_url", "http://localhost:8000/v1")).rstrip("/")
    try:
        with urllib.request.urlopen(base + "/models", timeout=2) as r:
            return r.status == 200
    except Exception:
        return False


def degrade_plan(cfg: Config, worker: str, verdict: "GuardVerdict",
                 backend: str | None = None) -> tuple[str, str | None]:
    """한도 인근 적응형 열화 결정(P1: 모델 다운그레이드). 반환 (action, model|None).

    action='downgrade'면 이번 호출에 lite 모델을 주입한다. 순수 함수(부수효과 없음)라
    결정적으로 테스트된다. opt-in(guard.degrade.enabled)이며, 리뷰어 등 품질 게이트
    역할(roles_no_downgrade)은 제외한다 — 리뷰어를 낮추면 검수 자체가 약해지므로.
    """
    d = (cfg.yok3x.get("guard") or {}).get("degrade") or {}
    if not d.get("enabled"):
        return ("normal", None)
    if worker in (d.get("roles_no_downgrade") or []):
        return ("normal", None)
    if verdict.ratio >= float(d.get("downgrade_ratio", 0.9)):
        b = backend or _worker_backend_name(cfg, worker)   # 라우팅된 backend 우선
        lite = (((cfg.yok3x.get("limits") or {}).get(b) or {}).get("models") or {}).get("lite")
        if lite:
            return ("downgrade", lite)
    return ("normal", None)


# ---------------------------------------------------------------- coach

def _time_to_reset() -> str:
    now = datetime.now()
    reset = (now + timedelta(days=1)).replace(hour=0, minute=0, second=0, microsecond=0)
    dt = reset - now
    h, m = divmod(int(dt.total_seconds()) // 60, 60)
    return f"{h}시간 {m}분 후(자정) 리셋"


def _window(v: GuardVerdict, name: str) -> "limits.Window | None":
    if not v.reading:
        return None
    for w in v.reading.windows:
        if w.name == name:
            return w
    return None


def coach_messages(cfg: Config) -> list[str]:
    """'어느 작업을 · 왜 · 언제' 코칭. 실측 한도가 있으면 5시간/7일 이중 윈도우로 코칭한다."""
    g = cfg.yok3x["guard"]
    soft = g.get("soft_ratio", 0.8)
    verdicts = {b: check_backend(cfg, b) for b in BACKEND_KEYS}
    routing = cfg.yok3x.get("routing", {})
    msgs: list[str] = []
    ordered = sorted(verdicts.values(), key=lambda v: v.ratio)
    freest = ordered[0].backend

    for b in BACKEND_KEYS:
        v = verdicts[b]
        tasks_here = "/".join(t for t, bk in routing.items() if bk == b) or "해당"
        alt = freest if freest != b else ordered[1].backend
        w5, w7 = _window(v, "5h"), _window(v, "7d")
        # 어느 작업을 · 왜(사용률) · 언제(리셋) 3요소
        win_str = ""
        if w5 or w7:
            parts = []
            if w5:
                parts.append(f"5시간 {w5.used_percent:.0f}%(리셋 {w5.reset_in()})")
            if w7:
                parts.append(f"7일 {w7.used_percent:.0f}%(리셋 {w7.reset_in()})")
            win_str = " · ".join(parts)
        why = win_str or f"{v.metric} {v.ratio:.0%} ({v.detail})"
        src = "실측" if v.real else ("추정" if v.reading else "원장")

        if v.level == "stop":
            msgs.append(f"[정지·{src}] {b} 한도 초과 — {why}. "
                        f"{tasks_here} 작업을 지금 {alt}로 돌리거나 리셋까지 대기하라.")
        elif v.level == "warn":
            msgs.append(f"[경고·{src}] {b} {why}. "
                        f"비필수 {tasks_here} 작업은 여유 있는 {alt}(사용률 {verdicts[alt].ratio:.0%})로 옮겨라.")
        else:
            # 여유 — 단기 한도가 곧 리셋되면 '지금 큰 작업 밀어붙이기' 코칭
            hint = f"{tasks_here} 등 큰 작업 지금 돌리기 좋다."
            if w5 and w5.resets_at and (w5.reset_in().startswith(("0시간", "1시간"))) and w5.used_percent < soft * 100:
                hint = f"5시간 창이 곧 리셋({w5.reset_in()})되고 사용률도 낮다 — 지금 큰 배치를 밀어붙여라."
            msgs.append(f"[여유·{src}] {b} {why}. {hint}")
    return msgs


def guard_toggle(cfg: Config, on: bool) -> None:
    cfg.yok3x["guard"]["enabled"] = on
    cfg.save_yok3x()
