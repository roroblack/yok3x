"""하네스 멀티 에이전트 v2.3 — Claude Code · Codex · Gemini CLI 코딩 오케스트레이터.

라이브 한도 실측 가드 · producer-reviewer 교차검증 · 하네스 기법(계획→구현→검증 루프)
· 할루시네이션 방지 · GUI 프로토타입.
"""
__version__ = "2.3.0"
