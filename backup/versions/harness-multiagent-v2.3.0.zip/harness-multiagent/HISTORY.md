# HISTORY.md — 변경 이력

형식: `버전 · 날짜 시간 — 변경 요약`. 갱신할 때마다 맨 위에 새 항목을 추가한다.

---

## v2.3.0 · 2026-07-04 13:36 — 코딩 전환 + 라이브 한도 + GUI 프로토타입

- **GUI 프로토타입** (`harness gui`): 브라우저 콘솔. claude 코믹 베이스 + lovable 폴리시(둥근 파스텔 패널·소스배지·상태색). 본문/데이터는 가독성 산세리프, 코드·로그·수치는 코딩 폰트(D2Coding→Consolas 폴백), 제목만 코믹. **CDN 0(오프라인)**. `harness/guiserver.py`가 `/api/state`로 실제 limits/coach/runs를 서빙 — 목업이 아니라 **라이브 데이터**.
- **하네스 기법 주입** (`orchestrator.HARNESS_TECHNIQUE`): 코딩 워커에 계획→구현→자가검증(SELF-CHECK) 구조 강제. 4중 브레이크(단계분할·승인·검증·예산).
- **할루시네이션 방지** (`ANTI_HALLUCINATION`/`REVIEW_GUARD`): 전 워커에 사실성 규칙 주입, 검수 워커는 환각 명시 지적, 체크리스트가 근거 없는 과잉 확신 표현 자동 표시.
- **요금제 프리셋 + 캘리브레이트**: `harness plan claude max20x`(근사), `harness calibrate claude 7d <실제%>`(현재 롤링 토큰 ÷ 실제% 로 정확 역산). codex는 plan 자동 감지.
- **코딩용 전환**: 워커 역할(codex-critic=코드 리뷰어 등)·라우팅(build/refactor/review/test/design_review)·샘플 태스크(슬러그 함수·LRU 캐시·CSV 파싱)를 코딩 워크플로우로 교체.
- **RULE.md · HISTORY.md** 추가.
- 버전 2.2 → 2.3.

## v2.2.2 · 2026-07-04 09:45 — 라이브 codex 실측(app-server RPC)

- `limits.codex_appserver`: `codex app-server` JSON-RPC(`account/rateLimits/read`)로 **지금 이 순간** 5h/7d `usedPercent`·리셋시각 조회. 세션 파일(stale) 방식을 대체. 라이브 실패 시 파일→원장 폴백.
- 근거: 세션 rollout 파일은 마지막 값이라 시간이 지나면 부정확(stale) — 실측 검증으로 확인(파일 7d 5% vs 라이브 24%). claude/gemini는 라이브 소스 부재 확인(추정/원장 유지).

## v2.2.1 · 2026-07-04 05:37 — 진짜 한도 조회 + Windows 수정

- `limits.py` 신설: codex_sessions(파일 실측)·claude_transcripts(롤링 추정)·command(ccusage/tokscale)·ledger. 가드가 실측 우선 + `on_probe_failure` 폴백 정책.
- coach 5h/7d 이중 윈도우 코칭, mat에 소스배지 표시.
- **Windows 수정**: 설정·태스크·노트 읽기 `utf-8-sig`(BOM 크래시 제거), CLI `.cmd` 심 해석(`shutil.which`), stdout/stderr UTF-8 재구성(cp949 콘솔 게이지 깨짐 방지), BrokenPipe 방어.

## v2.2.0 · 2026-07-04 — 초기 구현 (원 매뉴얼 v2.2 기반)

- 요금 가드(루프 자동 정지)·coach·mat·producer-reviewer 교차검증·knot 지식그물·flavor 3종·backends 어댑터(cli/native/mcp/mock)·승인 게이트·파일 로그·context/brief 글자 제한·Fan-out/Pipeline/Producer-Reviewer 패턴.
